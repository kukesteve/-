package com.tuoyan.hero

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.tuoyan.hero.ui.screens.*
import com.tuoyan.hero.ui.theme.HeroTheme
import com.tuoyan.hero.viewmodel.*

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* 用户选择后不需要额外操作 */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestNotificationPermission()

        val app = application as HeroApp

        setContent {
            HeroTheme {
                val navController = rememberNavController()

                // ViewModels
                val homeViewModel: HomeViewModel = viewModel(
                    factory = HomeViewModel.Factory(app.taskRepository, app.characterRepository)
                )
                val taskViewModel: TaskViewModel = viewModel(
                    factory = TaskViewModel.Factory(app.taskRepository, app.characterRepository)
                )
                val timerViewModel: TimerViewModel = viewModel(
                    factory = TimerViewModel.Factory(application, app.taskRepository, app.characterRepository)
                )

                // 初始化角色
                LaunchedEffect(Unit) {
                    homeViewModel.initCharacter()
                }

                NavHost(
                    navController = navController,
                    startDestination = "home",
                    modifier = Modifier.fillMaxSize()
                ) {
                    composable("home") {
                        val homeState by homeViewModel.homeState.collectAsState()

                        HomeScreen(
                            state = homeState,
                            onNavigateToTimer = { navController.navigate("timer") },
                            onNavigateToTasks = { navController.navigate("tasks") },
                            onNavigateToCharacter = { navController.navigate("character") },
                            onNavigateToAchievements = { navController.navigate("achievements") },
                            onTaskClick = { taskId ->
                                taskViewModel.selectTask(taskId)
                                navController.navigate("tasks")
                            }
                        )
                    }

                    composable("timer") {
                        val timerState by timerViewModel.timerState.collectAsState()

                        TimerScreen(
                            timerState = timerState,
                            onSetDuration = { timerViewModel.setDuration(it) },
                            onStart = { timerViewModel.startTimer() },
                            onStop = { timerViewModel.stopTimer() },
                            onPause = { timerViewModel.pauseTimer() },
                            onResume = { timerViewModel.resumeTimer() },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("tasks") {
                        val tasks by taskViewModel.tasks.collectAsState()
                        val selectedTaskId by taskViewModel.selectedTaskId.collectAsState()
                        val subTasks by taskViewModel.subTasks.collectAsState()

                        TaskScreen(
                            tasks = tasks,
                            selectedTaskId = selectedTaskId,
                            subTasks = subTasks,
                            onAddTask = { taskViewModel.addTask(it) },
                            onDeleteTask = { taskViewModel.deleteTask(it) },
                            onSelectTask = { id ->
                                if (id == -1L) {
                                    taskViewModel.clearSelection()
                                } else {
                                    taskViewModel.selectTask(id)
                                }
                            },
                            onBack = {
                                if (selectedTaskId != null) {
                                    taskViewModel.clearSelection()
                                } else {
                                    navController.popBackStack()
                                }
                            },
                            onAddSubTask = { taskViewModel.addSubTask(selectedTaskId ?: return@TaskScreen, it) },
                            onToggleSubTask = { taskViewModel.toggleSubTask(it) },
                            onDeleteSubTask = { taskViewModel.deleteSubTask(it) },
                            onSetActiveSubTask = { taskViewModel.setActiveSubTask(it) }
                        )
                    }

                    composable("character") {
                        val homeState by homeViewModel.homeState.collectAsState()

                        CharacterScreen(
                            character = homeState.character,
                            totalFocusMinutes = homeState.totalFocusMinutes,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("achievements") {
                        var achievements by remember { mutableStateOf(emptyList<com.tuoyan.hero.data.model.Achievement>()) }
                        var unlockedCount by remember { mutableIntStateOf(0) }

                        LaunchedEffect(Unit) {
                            app.characterRepository.allAchievements.collect {
                                achievements = it
                                unlockedCount = it.count { a -> a.isUnlocked }
                            }
                        }

                        AchievementScreen(
                            achievements = achievements,
                            unlockedCount = unlockedCount,
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
