package com.tuoyan.hero.data.database

import androidx.room.*
import com.tuoyan.hero.data.model.Achievement
import com.tuoyan.hero.data.model.HeroCharacter
import com.tuoyan.hero.data.model.TimerSession
import kotlinx.coroutines.flow.Flow

@Dao
interface CharacterDao {

    // HeroCharacter
    @Query("SELECT * FROM hero_character WHERE id = 1")
    fun getCharacter(): Flow<HeroCharacter?>

    @Query("SELECT * FROM hero_character WHERE id = 1")
    suspend fun getCharacterSync(): HeroCharacter?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCharacter(character: HeroCharacter)

    @Update
    suspend fun updateCharacter(character: HeroCharacter)

    @Query("UPDATE hero_character SET currentXp = :xp, level = :level, title = :title WHERE id = 1")
    suspend fun updateXpAndLevel(xp: Int, level: Int, title: String)

    @Query("UPDATE hero_character SET totalFocusMinutes = totalFocusMinutes + :minutes WHERE id = 1")
    suspend fun addFocusMinutes(minutes: Int)

    @Query("UPDATE hero_character SET completedSubTasks = completedSubTasks + 1 WHERE id = 1")
    suspend fun incrementCompletedSubTasks()

    // TimerSession
    @Query("SELECT * FROM timer_sessions ORDER BY completedAt DESC")
    fun getAllTimerSessions(): Flow<List<TimerSession>>

    @Insert
    suspend fun insertTimerSession(session: TimerSession)

    @Query("SELECT COALESCE(SUM(durationMinutes), 0) FROM timer_sessions")
    fun getTotalFocusMinutes(): Flow<Int>

    // Achievements
    @Query("SELECT * FROM achievements ORDER BY id ASC")
    fun getAllAchievements(): Flow<List<Achievement>>

    @Insert
    suspend fun insertAchievement(achievement: Achievement)

    @Insert
    suspend fun insertAchievements(achievements: List<Achievement>)

    @Query("UPDATE achievements SET progress = :progress, isUnlocked = :isUnlocked WHERE id = :id")
    suspend fun updateAchievementProgress(id: Long, progress: Int, isUnlocked: Boolean)

    @Query("SELECT * FROM achievements WHERE isUnlocked = true")
    fun getUnlockedAchievements(): Flow<List<Achievement>>

    @Query("SELECT COUNT(*) FROM achievements WHERE isUnlocked = true")
    fun getUnlockedAchievementCount(): Flow<Int>
}
