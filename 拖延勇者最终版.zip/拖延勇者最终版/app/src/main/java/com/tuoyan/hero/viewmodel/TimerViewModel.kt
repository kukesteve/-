package com.tuoyan.hero.viewmodel

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.tuoyan.hero.data.repository.CharacterRepository
import com.tuoyan.hero.data.repository.TaskRepository
import com.tuoyan.hero.service.TimerService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class TimerState(
    val isRunning: Boolean = false,
    val remainingSeconds: Int = 0,
    val totalSeconds: Int = 0,
    val durationMinutes: Int = 30,
    val isPaused: Boolean = false
)

class TimerViewModel(
    private val application: Application,
    private val taskRepository: TaskRepository,
    private val characterRepository: CharacterRepository
) : ViewModel() {

    private val _timerState = MutableStateFlow(TimerState())
    val timerState: StateFlow<TimerState> = _timerState.asStateFlow()

    private var timerService: TimerService? = null
    private var isServiceBound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as TimerService.TimerBinder
            timerService = binder.getService()
            timerService?.setCallbacks(
                onTick = { remaining ->
                    val state = _timerState.value
                    _timerState.value = state.copy(remainingSeconds = remaining)
                },
                onFinish = {
                    onTimerFinished()
                }
            )

            // 如果服务已经在运行，同步状态
            if (timerService?.isTimerRunning() == true) {
                val elapsed = timerService?.getElapsedSeconds() ?: 0
                val total = timerService?.getTotalDurationSeconds() ?: 0
                _timerState.value = _timerState.value.copy(
                    isRunning = true,
                    remainingSeconds = total - elapsed,
                    totalSeconds = total
                )
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            timerService = null
        }
    }

    fun setDuration(minutes: Int) {
        if (!_timerState.value.isRunning) {
            _timerState.value = _timerState.value.copy(durationMinutes = minutes)
        }
    }

    fun startTimer() {
        val intent = Intent(application, TimerService::class.java)
        application.bindService(intent, connection, Context.BIND_AUTO_CREATE)

        val duration = _timerState.value.durationMinutes
        _timerState.value = _timerState.value.copy(
            isRunning = true,
            remainingSeconds = duration * 60,
            totalSeconds = duration * 60,
            isPaused = false
        )

        application.startForegroundService(Intent(application, TimerService::class.java))

        // 等待绑定完成再启动
        viewModelScope.launch {
            kotlinx.coroutines.delay(300)
            timerService?.startTimer(duration)
        }
    }

    fun stopTimer() {
        timerService?.stopTimer()
        _timerState.value = TimerState(durationMinutes = _timerState.value.durationMinutes)
        unbindService()
    }

    fun pauseTimer() {
        timerService?.pauseTimer()
        _timerState.value = _timerState.value.copy(isRunning = false, isPaused = true)
    }

    fun resumeTimer() {
        timerService?.resumeTimer()
        _timerState.value = _timerState.value.copy(isRunning = true, isPaused = false)
    }

    private fun onTimerFinished() {
        val duration = _timerState.value.durationMinutes
        viewModelScope.launch {
            characterRepository.addFocusSession(duration)
        }
        _timerState.value = TimerState(durationMinutes = _timerState.value.durationMinutes)
        unbindService()
    }

    private fun unbindService() {
        if (isServiceBound) {
            try {
                application.unbindService(connection)
            } catch (_: Exception) {}
            isServiceBound = false
        }
    }

    override fun onCleared() {
        super.onCleared()
        unbindService()
    }

    class Factory(
        private val application: Application,
        private val taskRepository: TaskRepository,
        private val characterRepository: CharacterRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return TimerViewModel(application, taskRepository, characterRepository) as T
        }
    }
}
