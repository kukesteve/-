package com.tuoyan.hero.ui.theme

import androidx.compose.ui.graphics.Color

// 像素风 RPG 配色
val PixelDark = Color(0xFF1A1A2E)
val PixelDarker = Color(0xFF0F0F23)
val PixelCard = Color(0xFF16213E)
val PixelAccent = Color(0xFFE94560)
val PixelGold = Color(0xFFF5C518)
val PixelGreen = Color(0xFF4CAF50)
val PixelBlue = Color(0xFF0F3460)
val PixelLight = Color(0xFFE8E8E8)
val PixelGray = Color(0xFF8A8A8A)
val PixelRed = Color(0xFFE74C3C)
val PixelPurple = Color(0xFF9B59B6)
val PixelCyan = Color(0xFF00BCD4)
val PixelOrange = Color(0xFFFF9800)
val PixelWhite = Color(0xFFF5F5F5)
val PixelBorder = Color(0xFF2A2A4A)
val PixelXpBar = Color(0xFF64FFDA)
