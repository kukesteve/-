package com.tuoyan.hero.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "hero_character")
data class HeroCharacter(
    @PrimaryKey
    val id: Int = 1,  // 单例，始终为 1
    val level: Int = 1,
    val currentXp: Int = 0,
    val xpToNextLevel: Int = 100,
    val title: String = "见习勇者",
    val skin: String = "warrior_default",
    val totalFocusMinutes: Int = 0,
    val completedSubTasks: Int = 0
) {
    companion object {
        fun xpForLevel(level: Int): Int = level * 100

        val TITLES = listOf(
            "见习勇者",
            "初心冒险者",
            "独行旅人",
            "专注剑士",
            "时间法师",
            "毅力骑士",
            "拖延克星",
            "效率大师",
            "传说勇者",
            "时间主宰"
        )

        fun titleForLevel(level: Int): String {
            val index = (level - 1).coerceIn(0, TITLES.lastIndex)
            return TITLES[index]
        }
    }
}
