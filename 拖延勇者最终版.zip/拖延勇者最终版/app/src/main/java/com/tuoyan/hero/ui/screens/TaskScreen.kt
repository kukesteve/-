package com.tuoyan.hero.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuoyan.hero.data.model.SubTask
import com.tuoyan.hero.data.model.Task
import com.tuoyan.hero.ui.components.*
import com.tuoyan.hero.ui.theme.*

@Composable
fun TaskScreen(
    tasks: List<Task>,
    selectedTaskId: Long?,
    subTasks: List<SubTask>,
    onAddTask: (String) -> Unit,
    onDeleteTask: (Task) -> Unit,
    onSelectTask: (Long) -> Unit,
    onBack: () -> Unit,
    onAddSubTask: (String) -> Unit,
    onToggleSubTask: (SubTask) -> Unit,
    onDeleteSubTask: (SubTask) -> Unit,
    onSetActiveSubTask: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddTaskDialog by remember { mutableStateOf(false) }
    var showAddSubTaskDialog by remember { mutableStateOf(false) }

    if (showAddTaskDialog) {
        PixelInputDialog(
            title = "📋 新建任务",
            placeholder = "输入任务名称",
            onConfirm = {
                onAddTask(it)
                showAddTaskDialog = false
            },
            onDismiss = { showAddTaskDialog = false }
        )
    }

    if (showAddSubTaskDialog) {
        PixelInputDialog(
            title = "📝 添加子步骤",
            placeholder = "输入步骤名称",
            onConfirm = {
                onAddSubTask(it)
                showAddSubTaskDialog = false
            },
            onDismiss = { showAddSubTaskDialog = false }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PixelDark)
            .padding(16.dp)
    ) {
        // 顶部
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            PixelIconButton(text = "← 返回", onClick = onBack)

            if (selectedTaskId == null) {
                PixelIconButton(text = "+ 新任务", onClick = { showAddTaskDialog = true })
            } else {
                PixelIconButton(text = "+ 子步骤", onClick = { showAddSubTaskDialog = true })
            }
        }

        Spacer(Modifier.height(12.dp))

        if (selectedTaskId == null) {
            // 任务列表视图
            Text(
                text = "═ 任务列表 ═",
                color = PixelGray,
                fontFamily = PixelFontFamily,
                fontSize = 12.sp,
                letterSpacing = 2.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            if (tasks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "还没有任务\n点击右上角 + 创建一个",
                        color = PixelGray,
                        fontFamily = PixelFontFamily,
                        fontSize = 14.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(tasks, key = { it.id }) { task ->
                        TaskCard(
                            task = task,
                            onClick = { onSelectTask(task.id) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        } else {
            // 子任务详情视图
            val selectedTask = tasks.find { it.id == selectedTaskId }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = selectedTask?.title ?: "",
                    color = PixelGold,
                    fontFamily = PixelFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    modifier = Modifier.weight(1f)
                )
                PixelIconButton(text = "← 返回列表", onClick = { onSelectTask(-1L) })
            }

            Spacer(Modifier.height(4.dp))

            Text(
                text = "子步骤（点击勾选框完成）：",
                color = PixelGray,
                fontFamily = PixelFontFamily,
                fontSize = 11.sp
            )

            Spacer(Modifier.height(8.dp))

            if (subTasks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "还没有子步骤\n点击右上角 + 添加",
                        color = PixelGray,
                        fontFamily = PixelFontFamily,
                        fontSize = 14.sp
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(subTasks, key = { it.id }) { subTask ->
                        SubTaskItem(
                            subTask = subTask,
                            onToggle = { onToggleSubTask(subTask) },
                            onSetActive = { onSetActiveSubTask(subTask.id) }
                        )
                    }
                }
            }
        }
    }
}
