package com.tuoyan.hero.data.database

import androidx.room.*
import com.tuoyan.hero.data.model.SubTask
import com.tuoyan.hero.data.model.Task
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {

    @Query("SELECT * FROM tasks ORDER BY createdAt DESC")
    fun getAllTasks(): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE id = :taskId")
    suspend fun getTaskById(taskId: Long): Task?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: Task): Long

    @Update
    suspend fun updateTask(task: Task)

    @Delete
    suspend fun deleteTask(task: Task)

    @Query("UPDATE tasks SET isCompleted = :isCompleted WHERE id = :taskId")
    suspend fun updateTaskCompletion(taskId: Long, isCompleted: Boolean)

    // SubTasks
    @Query("SELECT * FROM sub_tasks WHERE taskId = :taskId ORDER BY orderIndex ASC")
    fun getSubTasksByTaskId(taskId: Long): Flow<List<SubTask>>

    @Query("SELECT * FROM sub_tasks WHERE id = :subTaskId")
    suspend fun getSubTaskById(subTaskId: Long): SubTask?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubTask(subTask: SubTask): Long

    @Update
    suspend fun updateSubTask(subTask: SubTask)

    @Delete
    suspend fun deleteSubTask(subTask: SubTask)

    @Query("UPDATE sub_tasks SET isCompleted = :isCompleted WHERE id = :subTaskId")
    suspend fun updateSubTaskCompletion(subTaskId: Long, isCompleted: Boolean)

    @Query("UPDATE sub_tasks SET isActive = false WHERE isActive = true")
    suspend fun deactivateAllSubTasks()

    @Query("UPDATE sub_tasks SET isActive = true WHERE id = :subTaskId")
    suspend fun activateSubTask(subTaskId: Long)

    @Query("SELECT * FROM sub_tasks WHERE isActive = true LIMIT 1")
    suspend fun getActiveSubTask(): SubTask?

    @Query("SELECT COUNT(*) FROM sub_tasks WHERE isCompleted = true")
    fun getCompletedSubTaskCount(): Flow<Int>
}
