package com.tuoyan.hero.service

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.CountDownTimer
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationManagerCompat
import com.tuoyan.hero.notification.NotificationHelper
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

class TimerService : Service() {

    private val binder = TimerBinder()
    private val scheduler = Executors.newSingleThreadScheduledExecutor()
    private var tickFuture: ScheduledFuture<*>? = null
    private var timerEndTime: Long = 0
    private var isRunning = false
    private var elapsedSeconds = 0
    private var totalDurationSeconds = 0
    private var wakeLock: PowerManager.WakeLock? = null

    private var onTickCallback: ((Int) -> Unit)? = null
    private var onFinishCallback: (() -> Unit)? = null
    private var notificationManager: NotificationManagerCompat? = null

    inner class TimerBinder : Binder() {
        fun getService(): TimerService = this@TimerService
    }

    override fun onCreate() {
        super.onCreate()
        notificationManager = NotificationManagerCompat.from(this)
    }

    override fun onBind(intent: Intent?): IBinder = binder

    fun setCallbacks(onTick: (Int) -> Unit, onFinish: () -> Unit) {
        onTickCallback = onTick
        onFinishCallback = onFinish
    }

    fun startTimer(durationMinutes: Int) {
        totalDurationSeconds = durationMinutes * 60
        elapsedSeconds = 0
        isRunning = true
        timerEndTime = System.currentTimeMillis() + totalDurationSeconds * 1000L

        startForeground(
            NotificationHelper.NOTIFICATION_ID_TIMER,
            NotificationHelper.buildTimerNotification(this, 0, true).build()
        )

        // 获取唤醒锁，防止计时时 CPU 休眠
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "拖延勇者:TimerWakeLock"
        )
        wakeLock?.acquire(totalDurationSeconds * 1000L + 10000L)

        // 每秒更新
        tickFuture = scheduler.scheduleAtFixedRate({
            elapsedSeconds++
            val remaining = totalDurationSeconds - elapsedSeconds

            // 更新通知
            notificationManager?.notify(
                NotificationHelper.NOTIFICATION_ID_TIMER,
                NotificationHelper.buildTimerNotification(this, elapsedSeconds, true).build()
            )

            // 回调 UI
            onTickCallback?.invoke(remaining)

            // 时间到
            if (elapsedSeconds >= totalDurationSeconds) {
                finishTimer()
            }
        }, 0, 1, TimeUnit.SECONDS)
    }

    private fun finishTimer() {
        stopTimer()
        onFinishCallback?.invoke()
    }

    fun stopTimer() {
        isRunning = false
        tickFuture?.cancel(true)
        tickFuture = null
        wakeLock?.release()
        wakeLock = null

        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {}

        stopSelf()
    }

    fun pauseTimer() {
        if (!isRunning) return
        isRunning = false
        tickFuture?.cancel(true)
        tickFuture = null
        wakeLock?.release()
        wakeLock = null

        // 更新通知为暂停状态
        notificationManager?.notify(
            NotificationHelper.NOTIFICATION_ID_TIMER,
            NotificationHelper.buildTimerNotification(this, elapsedSeconds, false).build()
        )
    }

    fun resumeTimer() {
        if (isRunning) return
        isRunning = true
        timerEndTime = System.currentTimeMillis() + (totalDurationSeconds - elapsedSeconds) * 1000L

        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "拖延勇者:TimerWakeLock"
        )
        wakeLock?.acquire((totalDurationSeconds - elapsedSeconds) * 1000L + 10000L)

        tickFuture = scheduler.scheduleAtFixedRate({
            elapsedSeconds++
            val remaining = totalDurationSeconds - elapsedSeconds

            notificationManager?.notify(
                NotificationHelper.NOTIFICATION_ID_TIMER,
                NotificationHelper.buildTimerNotification(this, elapsedSeconds, true).build()
            )

            onTickCallback?.invoke(remaining)

            if (elapsedSeconds >= totalDurationSeconds) {
                finishTimer()
            }
        }, 0, 1, TimeUnit.SECONDS)

        startForeground(
            NotificationHelper.NOTIFICATION_ID_TIMER,
            NotificationHelper.buildTimerNotification(this, elapsedSeconds, true).build()
        )
    }

    fun isTimerRunning(): Boolean = isRunning
    fun getElapsedSeconds(): Int = elapsedSeconds
    fun getTotalDurationSeconds(): Int = totalDurationSeconds

    override fun onDestroy() {
        tickFuture?.cancel(true)
        wakeLock?.release()
        scheduler.shutdown()
        super.onDestroy()
    }
}
