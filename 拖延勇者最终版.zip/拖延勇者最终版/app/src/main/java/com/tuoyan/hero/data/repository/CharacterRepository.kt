package com.tuoyan.hero.data.repository

import com.tuoyan.hero.data.database.CharacterDao
import com.tuoyan.hero.data.model.Achievement
import com.tuoyan.hero.data.model.HeroCharacter
import com.tuoyan.hero.data.model.TimerSession
import kotlinx.coroutines.flow.Flow

class CharacterRepository(private val characterDao: CharacterDao) {

    val character: Flow<HeroCharacter?> = characterDao.getCharacter()
    val totalFocusMinutes: Flow<Int> = characterDao.getTotalFocusMinutes()
    val allAchievements: Flow<List<Achievement>> = characterDao.getAllAchievements()
    val unlockedAchievementCount: Flow<Int> = characterDao.getUnlockedAchievementCount()

    suspend fun initCharacter() {
        val existing = characterDao.getCharacterSync()
        if (existing == null) {
            characterDao.insertCharacter(HeroCharacter())
            insertDefaultAchievements()
        }
    }

    suspend fun addFocusSession(durationMinutes: Int, subTaskId: Long? = null) {
        characterDao.addFocusMinutes(durationMinutes)
        characterDao.insertTimerSession(TimerSession(durationMinutes = durationMinutes, subTaskId = subTaskId))
        addXp(durationMinutes)  // 每专注1分钟=1经验
        checkAchievements()
    }

    suspend fun completeSubTask() {
        characterDao.incrementCompletedSubTasks()
        addXp(50)  // 完成一个子步骤得50经验
        checkAchievements()
    }

    private suspend fun addXp(amount: Int) {
        val char = characterDao.getCharacterSync() ?: return
        var newXp = char.currentXp + amount
        var newLevel = char.level
        var xpToNext = char.xpToNextLevel

        while (newXp >= xpToNext) {
            newXp -= xpToNext
            newLevel++
            xpToNext = HeroCharacter.xpForLevel(newLevel)
        }

        val newTitle = HeroCharacter.titleForLevel(newLevel)
        characterDao.updateXpAndLevel(newXp, newLevel, newTitle)
    }

    private suspend fun checkAchievements() {
        val char = characterDao.getCharacterSync() ?: return
        val achievements = characterDao.getAllAchievements()

        achievements.collect { list ->
            list.forEach { achievement ->
                if (!achievement.isUnlocked) {
                    val progress = when (achievement.requirementType) {
                        "focus_minutes" -> char.totalFocusMinutes
                        "sub_tasks" -> char.completedSubTasks
                        "level" -> char.level
                        else -> 0
                    }
                    val unlocked = progress >= achievement.requirementValue
                    if (unlocked || progress > achievement.progress) {
                        characterDao.updateAchievementProgress(
                            achievement.id,
                            progress.coerceAtMost(achievement.requirementValue),
                            unlocked
                        )
                    }
                }
            }
        }
    }

    private suspend fun insertDefaultAchievements() {
        val achievements = listOf(
            Achievement(name = "第一次专注", description = "完成第1次番茄专注", icon = "🔥", requirementType = "focus_minutes", requirementValue = 1),
            Achievement(name = "专注新手", description = "累计专注30分钟", icon = "⏰", requirementType = "focus_minutes", requirementValue = 30),
            Achievement(name = "专注达人", description = "累计专注3小时", icon = "⚔️", requirementType = "focus_minutes", requirementValue = 180),
            Achievement(name = "专注大师", description = "累计专注10小时", icon = "👑", requirementType = "focus_minutes", requirementValue = 600),
            Achievement(name = "第一步", description = "完成第1个子任务", icon = "📋", requirementType = "sub_tasks", requirementValue = 1),
            Achievement(name = "任务猎人", description = "完成10个子任务", icon = "🏹", requirementType = "sub_tasks", requirementValue = 10),
            Achievement(name = "任务终结者", description = "完成50个子任务", icon = "💀", requirementType = "sub_tasks", requirementValue = 50),
            Achievement(name = "初出茅庐", description = "角色升到第3级", icon = "⭐", requirementType = "level", requirementValue = 3),
            Achievement(name = "小有名气", description = "角色升到第5级", icon = "🌟", requirementType = "level", requirementValue = 5),
            Achievement(name = "传说勇者", description = "角色升到第10级", icon = "🏆", requirementType = "level", requirementValue = 10),
        )
        characterDao.insertAchievements(achievements)
    }
}
