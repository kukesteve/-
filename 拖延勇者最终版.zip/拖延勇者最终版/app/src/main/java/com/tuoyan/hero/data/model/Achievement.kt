package com.tuoyan.hero.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "achievements")
data class Achievement(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val description: String,
    val icon: String = "🌟",
    val requirementType: String,  // "focus_minutes" | "sub_tasks" | "level" | "streak_days"
    val requirementValue: Int,
    val progress: Int = 0,
    val isUnlocked: Boolean = false
)
