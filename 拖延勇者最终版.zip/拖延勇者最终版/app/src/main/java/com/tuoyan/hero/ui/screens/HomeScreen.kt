package com.tuoyan.hero.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuoyan.hero.data.model.HeroCharacter
import com.tuoyan.hero.data.model.Task
import com.tuoyan.hero.ui.components.PixelButton
import com.tuoyan.hero.ui.components.PixelProgressBar
import com.tuoyan.hero.ui.components.TaskCard
import com.tuoyan.hero.ui.theme.*
import com.tuoyan.hero.viewmodel.HomeState

@Composable
fun HomeScreen(
    state: HomeState,
    onNavigateToTimer: () -> Unit,
    onNavigateToTasks: () -> Unit,
    onNavigateToCharacter: () -> Unit,
    onNavigateToAchievements: () -> Unit,
    onTaskClick: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PixelDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // 标题
        Text(
            text = "⚔️ 拖延勇者",
            color = PixelGold,
            fontFamily = PixelFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 28.sp,
            letterSpacing = 3.sp,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // 角色状态卡片
        state.character?.let { char ->
            CharacterStatusCard(char)
        }

        Spacer(Modifier.height(12.dp))

        // 快捷操作
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PixelButton(
                text = "⏱️ 开始专注",
                onClick = onNavigateToTimer,
                color = PixelAccent,
                modifier = Modifier.weight(1f)
            )
            PixelButton(
                text = "📋 任务",
                onClick = onNavigateToTasks,
                color = PixelBlue,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PixelButton(
                text = "👤 角色",
                onClick = onNavigateToCharacter,
                color = PixelPurple,
                modifier = Modifier.weight(1f)
            )
            PixelButton(
                text = "🏆 成就",
                onClick = onNavigateToAchievements,
                color = PixelGold,
                textColor = PixelDark,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(16.dp))

        // 最近任务
        Text(
            text = "═ 最近任务 ═",
            color = PixelGray,
            fontFamily = PixelFontFamily,
            fontSize = 12.sp,
            letterSpacing = 2.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (state.recentTasks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PixelCard, RoundedCornerShape(4.dp))
                    .border(1.dp, PixelBorder, RoundedCornerShape(4.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "还没有任务，去创建一个吧！",
                    color = PixelGray,
                    fontFamily = PixelFontFamily,
                    fontSize = 13.sp
                )
            }
        } else {
            state.recentTasks.forEach { task ->
                TaskCard(
                    task = task,
                    onClick = { onTaskClick(task.id) },
                    modifier = Modifier.padding(bottom = 6.dp)
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // 统计数据
        Text(
            text = "═ 统计数据 ═",
            color = PixelGray,
            fontFamily = PixelFontFamily,
            fontSize = 12.sp,
            letterSpacing = 2.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        StatRow("累计专注", "${state.totalFocusMinutes} 分钟")
        state.character?.let { char ->
            StatRow("完成子任务", "${char.completedSubTasks} 个")
        }
    }
}

@Composable
private fun CharacterStatusCard(character: HeroCharacter) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(PixelCard, RoundedCornerShape(4.dp))
            .border(2.dp, PixelGold.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Lv.${character.level} ${character.title}",
                color = PixelGold,
                fontFamily = PixelFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Text(
                text = "EXP: ${character.currentXp}/${character.xpToNextLevel}",
                color = PixelXpBar,
                fontFamily = PixelFontFamily,
                fontSize = 11.sp
            )
        }
        Spacer(Modifier.height(6.dp))
        PixelProgressBar(
            progress = character.currentXp.toFloat() / character.xpToNextLevel,
            color = PixelXpBar,
            height = 8.dp
        )
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .background(PixelCard.copy(alpha = 0.5f), RoundedCornerShape(2.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = PixelGray,
            fontFamily = PixelFontFamily,
            fontSize = 13.sp
        )
        Text(
            text = value,
            color = PixelWhite,
            fontFamily = PixelFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
    }
}
