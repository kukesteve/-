package com.tuoyan.hero.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuoyan.hero.ui.theme.PixelAccent
import com.tuoyan.hero.ui.theme.PixelBorder
import com.tuoyan.hero.ui.theme.PixelDark
import com.tuoyan.hero.ui.theme.PixelFontFamily
import com.tuoyan.hero.ui.theme.PixelGold
import com.tuoyan.hero.ui.theme.PixelWhite

@Composable
fun PixelButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = PixelAccent,
    textColor: Color = PixelWhite,
    borderColor: Color = PixelBorder,
    width: Dp? = null
) {
    Box(
        modifier = modifier
            .then(if (width != null) Modifier.then(Modifier) else Modifier)
            .clip(RoundedCornerShape(4.dp))
            .border(2.dp, borderColor, RoundedCornerShape(4.dp))
            .background(color)
            .clickable(onClick = onClick)
            .then(if (width != null) Modifier.then(Modifier) else Modifier)
            .padding(horizontal = 24.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = textColor,
            fontFamily = PixelFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            letterSpacing = 2.sp
        )
    }
}

@Composable
fun PixelIconButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = PixelGold,
    textColor: Color = PixelDark
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .border(2.dp, PixelBorder, RoundedCornerShape(4.dp))
            .background(color)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = textColor,
            fontFamily = PixelFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
    }
}
