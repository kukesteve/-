package com.tuoyan.hero.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = PixelAccent,
    onPrimary = PixelWhite,
    primaryContainer = PixelRed,
    secondary = PixelGold,
    onSecondary = PixelDarker,
    secondaryContainer = PixelOrange,
    tertiary = PixelCyan,
    background = PixelDark,
    onBackground = PixelWhite,
    surface = PixelCard,
    onSurface = PixelWhite,
    surfaceVariant = PixelBlue,
    onSurfaceVariant = PixelGray,
    outline = PixelBorder,
    error = PixelRed
)

@Composable
fun HeroTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
