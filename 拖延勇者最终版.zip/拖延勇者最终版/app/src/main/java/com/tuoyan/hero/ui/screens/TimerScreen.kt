package com.tuoyan.hero.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuoyan.hero.ui.components.PixelButton
import com.tuoyan.hero.ui.components.PixelIconButton
import com.tuoyan.hero.ui.theme.*
import com.tuoyan.hero.viewmodel.TimerState

@Composable
fun TimerScreen(
    timerState: TimerState,
    onSetDuration: (Int) -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PixelDark)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 顶部返回
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start
        ) {
            PixelIconButton(text = "← 返回", onClick = onBack)
        }

        Spacer(Modifier.height(24.dp))

        // 标题
        Text(
            text = "⏱️ 专注计时",
            color = PixelGold,
            fontFamily = PixelFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            letterSpacing = 2.sp
        )

        Spacer(Modifier.height(32.dp))

        // 倒计时显示
        Box(
            modifier = Modifier
                .size(220.dp)
                .background(PixelCard, RoundedCornerShape(8.dp))
                .border(3.dp, PixelAccent, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            val minutes = timerState.remainingSeconds / 60
            val seconds = timerState.remainingSeconds % 60
            val timeText = String.format("%02d:%02d", minutes, seconds)

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = timeText,
                    color = if (timerState.isRunning) PixelAccent else PixelWhite,
                    fontFamily = PixelFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 56.sp,
                    letterSpacing = 4.sp,
                    textAlign = TextAlign.Center
                )

                if (!timerState.isRunning && !timerState.isPaused) {
                    Text(
                        text = "等待开始",
                        color = PixelGray,
                        fontFamily = PixelFontFamily,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                } else if (timerState.isPaused) {
                    Text(
                        text = "已暂停",
                        color = PixelGold,
                        fontFamily = PixelFontFamily,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                } else if (timerState.isRunning) {
                    Text(
                        text = "专注中...",
                        color = PixelGreen,
                        fontFamily = PixelFontFamily,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        // 计时器控制
        if (!timerState.isRunning && !timerState.isPaused) {
            // 设置时长
            Text(
                text = "设置时长",
                color = PixelGray,
                fontFamily = PixelFontFamily,
                fontSize = 12.sp,
                letterSpacing = 2.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(5, 10, 15, 25, 30, 45, 60).forEach { minutes ->
                    val isSelected = timerState.durationMinutes == minutes
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSelected) PixelAccent else PixelCard,
                                RoundedCornerShape(2.dp)
                            )
                            .border(
                                1.dp,
                                if (isSelected) PixelAccent else PixelBorder,
                                RoundedCornerShape(2.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "${minutes}分",
                            color = if (isSelected) PixelWhite else PixelGray,
                            fontFamily = PixelFontFamily,
                            fontSize = 12.sp,
                            modifier = Modifier.clickable { onSetDuration(minutes) }
                        )
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            PixelButton(
                text = "▶ 开始计时",
                onClick = onStart,
                color = PixelGreen,
                width = 200.dp
            )
        } else if (timerState.isPaused) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PixelButton(text = "▶ 继续", onClick = onResume, color = PixelGreen)
                PixelButton(text = "■ 停止", onClick = onStop, color = PixelRed)
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PixelButton(text = "⏸ 暂停", onClick = onPause, color = PixelGold, textColor = PixelDark)
                PixelButton(text = "■ 停止", onClick = onStop, color = PixelRed)
            }
        }

        Spacer(Modifier.height(24.dp))

        // 状态信息
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PixelCard, RoundedCornerShape(4.dp))
                .border(1.dp, PixelBorder, RoundedCornerShape(4.dp))
                .padding(12.dp)
        ) {
            Column {
                Text(
                    text = "📋 当前设置",
                    color = PixelGold,
                    fontFamily = PixelFontFamily,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "单次时长: ${timerState.durationMinutes} 分钟",
                    color = PixelWhite,
                    fontFamily = PixelFontFamily,
                    fontSize = 13.sp
                )
                Text(
                    text = "到点后自动按相同间隔重复提醒",
                    color = PixelGray,
                    fontFamily = PixelFontFamily,
                    fontSize = 11.sp
                )
            }
        }
    }
}
