package com.tuoyan.hero.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuoyan.hero.data.model.SubTask
import com.tuoyan.hero.data.model.Task
import com.tuoyan.hero.ui.theme.*

@Composable
fun TaskCard(
    task: Task,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(PixelCard, RoundedCornerShape(4.dp))
            .border(1.dp, PixelBorder, RoundedCornerShape(4.dp))
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = if (task.isCompleted) "✓ $title" else "🗡️ $title",
                color = if (task.isCompleted) PixelGray else PixelWhite,
                fontFamily = PixelFontFamily,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (task.description.isNotBlank()) {
                Text(
                    text = task.description,
                    color = PixelGray,
                    fontFamily = PixelFontFamily,
                    fontSize = 11.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
fun SubTaskItem(
    subTask: SubTask,
    onToggle: () -> Unit,
    onSetActive: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(
                if (subTask.isActive) PixelBlue.copy(alpha = 0.3f) else PixelDarker,
                RoundedCornerShape(2.dp)
            )
            .border(
                1.dp,
                if (subTask.isActive) PixelGold.copy(alpha = 0.5f) else PixelBorder,
                RoundedCornerShape(2.dp)
            )
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 完成勾选框
        Box(
            modifier = Modifier
                .size(24.dp)
                .background(
                    if (subTask.isCompleted) PixelGreen else PixelDarker,
                    RoundedCornerShape(2.dp)
                )
                .border(1.dp, PixelBorder, RoundedCornerShape(2.dp))
                .clickable(onClick = onToggle),
            contentAlignment = Alignment.Center
        ) {
            if (subTask.isCompleted) {
                Text("✓", color = PixelWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.width(8.dp))

        // 任务标题
        Text(
            text = subTask.title,
            color = if (subTask.isCompleted) PixelGray else PixelWhite,
            fontFamily = PixelFontFamily,
            fontSize = 13.sp,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Spacer(Modifier.width(8.dp))

        // 设置为当前步骤按钮
        if (!subTask.isCompleted && !subTask.isActive) {
            Box(
                modifier = Modifier
                    .background(PixelAccent.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                    .border(1.dp, PixelAccent, RoundedCornerShape(2.dp))
                    .clickable(onClick = onSetActive)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "专注",
                    color = PixelAccent,
                    fontFamily = PixelFontFamily,
                    fontSize = 10.sp
                )
            }
        }

        if (subTask.isActive) {
            Text(
                text = "▶ 进行中",
                color = PixelGold,
                fontFamily = PixelFontFamily,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
