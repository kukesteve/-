package com.tuoyan.hero.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.tuoyan.hero.data.model.Achievement
import com.tuoyan.hero.data.model.HeroCharacter
import com.tuoyan.hero.data.model.Task
import com.tuoyan.hero.data.repository.CharacterRepository
import com.tuoyan.hero.data.repository.TaskRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class HomeState(
    val character: HeroCharacter? = null,
    val recentTasks: List<Task> = emptyList(),
    val unlockedAchievements: List<Achievement> = emptyList(),
    val totalFocusMinutes: Int = 0
)

class HomeViewModel(
    private val taskRepository: TaskRepository,
    private val characterRepository: CharacterRepository
) : ViewModel() {

    private val _homeState = MutableStateFlow(HomeState())
    val homeState: StateFlow<HomeState> = _homeState.asStateFlow()

    init {
        viewModelScope.launch {
            characterRepository.character.collect { char ->
                _homeState.update { it.copy(character = char) }
            }
        }

        viewModelScope.launch {
            taskRepository.allTasks.collect { tasks ->
                _homeState.update { it.copy(recentTasks = tasks.take(3)) }
            }
        }

        viewModelScope.launch {
            characterRepository.unlockedAchievementCount.collect { /* refresh */ }
        }

        viewModelScope.launch {
            characterRepository.totalFocusMinutes.collect { minutes ->
                _homeState.update { it.copy(totalFocusMinutes = minutes) }
            }
        }
    }

    fun initCharacter() {
        viewModelScope.launch {
            characterRepository.initCharacter()
        }
    }

    class Factory(
        private val taskRepository: TaskRepository,
        private val characterRepository: CharacterRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HomeViewModel(taskRepository, characterRepository) as T
        }
    }
}
