package com.tuoyan.hero.data.repository

import com.tuoyan.hero.data.database.TaskDao
import com.tuoyan.hero.data.model.SubTask
import com.tuoyan.hero.data.model.Task
import kotlinx.coroutines.flow.Flow

class TaskRepository(private val taskDao: TaskDao) {

    val allTasks: Flow<List<Task>> = taskDao.getAllTasks()

    fun getSubTasks(taskId: Long): Flow<List<SubTask>> = taskDao.getSubTasksByTaskId(taskId)

    val completedSubTaskCount: Flow<Int> = taskDao.getCompletedSubTaskCount()

    suspend fun addTask(title: String, description: String = ""): Long {
        return taskDao.insertTask(Task(title = title, description = description))
    }

    suspend fun deleteTask(task: Task) = taskDao.deleteTask(task)

    suspend fun toggleTaskCompletion(taskId: Long, isCompleted: Boolean) {
        taskDao.updateTaskCompletion(taskId, isCompleted)
    }

    suspend fun addSubTask(taskId: Long, title: String): Long {
        return taskDao.insertSubTask(
            SubTask(taskId = taskId, title = title)
        )
    }

    suspend fun toggleSubTask(subTask: SubTask) {
        taskDao.updateSubTaskCompletion(subTask.id, !subTask.isCompleted)
    }

    suspend fun deleteSubTask(subTask: SubTask) = taskDao.deleteSubTask(subTask)

    suspend fun setActiveSubTask(subTaskId: Long) {
        taskDao.deactivateAllSubTasks()
        taskDao.activateSubTask(subTaskId)
    }

    suspend fun getActiveSubTask(): SubTask? = taskDao.getActiveSubTask()
}
