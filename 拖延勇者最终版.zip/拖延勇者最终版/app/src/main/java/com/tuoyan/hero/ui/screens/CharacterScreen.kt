package com.tuoyan.hero.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuoyan.hero.data.model.HeroCharacter
import com.tuoyan.hero.ui.components.PixelIconButton
import com.tuoyan.hero.ui.components.PixelProgressBar
import com.tuoyan.hero.ui.theme.*

@Composable
fun CharacterScreen(
    character: HeroCharacter?,
    totalFocusMinutes: Int,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PixelDark)
            .padding(16.dp)
    ) {
        // 顶部返回
        PixelIconButton(text = "← 返回", onClick = onBack)

        Spacer(Modifier.height(16.dp))

        Text(
            text = "👤 角色信息",
            color = PixelGold,
            fontFamily = PixelFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            letterSpacing = 2.sp
        )

        Spacer(Modifier.height(20.dp))

        character?.let { char ->
            // 角色头像占位
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .align(Alignment.CenterHorizontally)
                    .background(PixelCard, RoundedCornerShape(8.dp))
                    .border(3.dp, PixelGold.copy(alpha = 0.6f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "⚔️",
                    fontSize = 48.sp
                )
            }

            Spacer(Modifier.height(16.dp))

            // 等级称号
            Text(
                text = "Lv.${char.level}",
                color = PixelGold,
                fontFamily = PixelFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 32.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Text(
                text = char.title,
                color = PixelCyan,
                fontFamily = PixelFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            Spacer(Modifier.height(16.dp))

            // 经验条
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PixelCard, RoundedCornerShape(4.dp))
                    .border(1.dp, PixelBorder, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("经验值", color = PixelGray, fontFamily = PixelFontFamily, fontSize = 12.sp)
                        Text("${char.currentXp} / ${char.xpToNextLevel}", color = PixelXpBar, fontFamily = PixelFontFamily, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    PixelProgressBar(
                        progress = char.currentXp.toFloat() / char.xpToNextLevel,
                        color = PixelXpBar,
                        height = 12.dp
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // 详细属性
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PixelCard, RoundedCornerShape(4.dp))
                    .border(1.dp, PixelBorder, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "📊 属性",
                        color = PixelGold,
                        fontFamily = PixelFontFamily,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    AttributeRow("累计专注", "${totalFocusMinutes} 分钟", PixelAccent)
                    Spacer(Modifier.height(6.dp))
                    AttributeRow("完成子任务", "${char.completedSubTasks} 个", PixelGreen)
                }
            }

            Spacer(Modifier.height(12.dp))

            // 称号一览
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PixelCard, RoundedCornerShape(4.dp))
                    .border(1.dp, PixelBorder, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "🏅 称号列表",
                        color = PixelGold,
                        fontFamily = PixelFontFamily,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    HeroCharacter.TITLES.forEachIndexed { index, title ->
                        val level = index + 1
                        val isUnlocked = char.level >= level
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Lv.$level  $title",
                                color = if (isUnlocked) PixelWhite else PixelGray.copy(alpha = 0.5f),
                                fontFamily = PixelFontFamily,
                                fontSize = 12.sp
                            )
                            Text(
                                text = if (isUnlocked) "✓" else "?",
                                color = if (isUnlocked) PixelGreen else PixelGray,
                                fontFamily = PixelFontFamily,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AttributeRow(label: String, value: String, valueColor: androidx.compose.ui.graphics.Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(PixelDarker, RoundedCornerShape(2.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = PixelGray,
            fontFamily = PixelFontFamily,
            fontSize = 12.sp
        )
        Text(
            text = value,
            color = valueColor,
            fontFamily = PixelFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
    }
}
