package com.tuoyan.hero

import android.app.Application
import com.tuoyan.hero.data.database.AppDatabase
import com.tuoyan.hero.data.repository.CharacterRepository
import com.tuoyan.hero.data.repository.TaskRepository
import com.tuoyan.hero.notification.NotificationHelper

class HeroApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var taskRepository: TaskRepository
        private set

    lateinit var characterRepository: CharacterRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        taskRepository = TaskRepository(database.taskDao())
        characterRepository = CharacterRepository(database.characterDao())
        NotificationHelper.createChannels(this)
    }
}
