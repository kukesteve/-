package com.tuoyan.hero.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.tuoyan.hero.MainActivity
import com.tuoyan.hero.R

object NotificationHelper {

    const val CHANNEL_TIMER = "timer_channel"
    const val CHANNEL_TIMER_NAME = "专注计时"
    const val NOTIFICATION_ID_TIMER = 1001
    const val NOTIFICATION_ID_TIMEOUT = 1002

    fun createChannels(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val timerChannel = NotificationChannel(
            CHANNEL_TIMER,
            CHANNEL_TIMER_NAME,
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "显示当前专注计时状态"
            setShowBadge(false)
        }
        manager.createNotificationChannel(timerChannel)

        val timeoutChannel = NotificationChannel(
            "timer_timeout",
            "计时完成",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "计时结束时提醒"
            enableVibration(true)
        }
        manager.createNotificationChannel(timeoutChannel)
    }

    fun buildTimerNotification(
        context: Context,
        elapsedSeconds: Int,
        isRunning: Boolean
    ): NotificationCompat.Builder {
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val minutes = elapsedSeconds / 60
        val seconds = elapsedSeconds % 60
        val timeText = String.format("%02d:%02d", minutes, seconds)

        return NotificationCompat.Builder(context, CHANNEL_TIMER)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("⏱️ 拖延勇者 - 专注中")
            .setContentText("已专注 $timeText")
            .setOngoing(isRunning)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
    }

    fun buildTimeoutNotification(
        context: Context,
        intervalMinutes: Int
    ): NotificationCompat.Builder {
        val pendingIntent = PendingIntent.getActivity(
            context,
            1,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(context, "timer_timeout")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("⏰ 时间到了！")
            .setContentText("专注时间已结束，${intervalMinutes}分钟后将再次提醒")
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVibrate(longArrayOf(0, 500, 200, 500))
    }
}
