package com.tuoyan.hero.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.tuoyan.hero.data.model.SubTask
import com.tuoyan.hero.data.model.Task
import com.tuoyan.hero.data.repository.CharacterRepository
import com.tuoyan.hero.data.repository.TaskRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class TaskViewModel(
    private val taskRepository: TaskRepository,
    private val characterRepository: CharacterRepository
) : ViewModel() {

    val tasks: StateFlow<List<Task>> = taskRepository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedTaskId = MutableStateFlow<Long?>(null)
    val selectedTaskId: StateFlow<Long?> = _selectedTaskId.asStateFlow()

    val subTasks: StateFlow<List<SubTask>> = _selectedTaskId
        .flatMapLatest { id ->
            if (id != null) taskRepository.getSubTasks(id)
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectTask(taskId: Long) {
        _selectedTaskId.value = taskId
    }

    fun clearSelection() {
        _selectedTaskId.value = null
    }

    fun addTask(title: String) {
        viewModelScope.launch {
            taskRepository.addTask(title)
        }
    }

    fun deleteTask(task: Task) {
        viewModelScope.launch {
            taskRepository.deleteTask(task)
        }
    }

    fun addSubTask(taskId: Long, title: String) {
        viewModelScope.launch {
            taskRepository.addSubTask(taskId, title)
        }
    }

    fun toggleSubTask(subTask: SubTask) {
        viewModelScope.launch {
            taskRepository.toggleSubTask(subTask)
            if (!subTask.isCompleted) {
                characterRepository.completeSubTask()
            }
        }
    }

    fun deleteSubTask(subTask: SubTask) {
        viewModelScope.launch {
            taskRepository.deleteSubTask(subTask)
        }
    }

    fun setActiveSubTask(subTaskId: Long) {
        viewModelScope.launch {
            taskRepository.setActiveSubTask(subTaskId)
        }
    }

    class Factory(
        private val taskRepository: TaskRepository,
        private val characterRepository: CharacterRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return TaskViewModel(taskRepository, characterRepository) as T
        }
    }
}
