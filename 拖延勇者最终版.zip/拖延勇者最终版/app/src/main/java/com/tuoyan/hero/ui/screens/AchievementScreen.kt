package com.tuoyan.hero.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuoyan.hero.data.model.Achievement
import com.tuoyan.hero.ui.components.PixelIconButton
import com.tuoyan.hero.ui.components.PixelProgressBar
import com.tuoyan.hero.ui.theme.*

@Composable
fun AchievementScreen(
    achievements: List<Achievement>,
    unlockedCount: Int,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PixelDark)
            .padding(16.dp)
    ) {
        // 顶部
        PixelIconButton(text = "← 返回", onClick = onBack)

        Spacer(Modifier.height(12.dp))

        Text(
            text = "🏆 成就",
            color = PixelGold,
            fontFamily = PixelFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            letterSpacing = 2.sp
        )

        Spacer(Modifier.height(8.dp))

        // 成就进度
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PixelCard, RoundedCornerShape(4.dp))
                .border(1.dp, PixelBorder, RoundedCornerShape(4.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "已解锁: $unlockedCount / ${achievements.size}",
                        color = PixelGold,
                        fontFamily = PixelFontFamily,
                        fontSize = 13.sp
                    )
                }
                Spacer(Modifier.height(6.dp))
                PixelProgressBar(
                    progress = if (achievements.isEmpty()) 0f else unlockedCount.toFloat() / achievements.size,
                    color = PixelGold,
                    height = 10.dp
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        // 成就列表
        if (achievements.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "暂无可用的成就",
                    color = PixelGray,
                    fontFamily = PixelFontFamily,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(achievements, key = { it.id }) { achievement ->
                    AchievementCard(achievement = achievement)
                }
            }
        }
    }
}

@Composable
private fun AchievementCard(achievement: Achievement) {
    val isUnlocked = achievement.isUnlocked
    val progressFraction = if (achievement.requirementValue > 0)
        achievement.progress.toFloat() / achievement.requirementValue else 0f

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (isUnlocked) PixelCard else PixelDarker,
                RoundedCornerShape(4.dp)
            )
            .border(
                1.dp,
                if (isUnlocked) PixelGold.copy(alpha = 0.5f) else PixelBorder,
                RoundedCornerShape(4.dp)
            )
            .padding(12.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = achievement.icon,
                    fontSize = 24.sp,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = achievement.name,
                        color = if (isUnlocked) PixelGold else PixelGray,
                        fontFamily = PixelFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = achievement.description,
                        color = PixelGray,
                        fontFamily = PixelFontFamily,
                        fontSize = 11.sp
                    )
                }
                if (isUnlocked) {
                    Text(
                        text = "✓",
                        color = PixelGold,
                        fontFamily = PixelFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }

            if (!isUnlocked) {
                Spacer(Modifier.height(6.dp))
                PixelProgressBar(
                    progress = progressFraction,
                    color = PixelGray,
                    height = 6.dp
                )
                Text(
                    text = "${achievement.progress} / ${achievement.requirementValue}",
                    color = PixelGray.copy(alpha = 0.7f),
                    fontFamily = PixelFontFamily,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    }
}
