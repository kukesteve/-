package com.tuoyan.hero.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.tuoyan.hero.ui.theme.*

@Composable
fun PixelInputDialog(
    title: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
    placeholder: String = ""
) {
    var input by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .background(PixelCard, RoundedCornerShape(4.dp))
                .border(2.dp, PixelAccent, RoundedCornerShape(4.dp))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                color = PixelGold,
                fontFamily = PixelFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                letterSpacing = 1.sp
            )

            Spacer(Modifier.height(16.dp))

            androidx.compose.material3.OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = {
                    Text(placeholder, color = PixelGray, fontFamily = PixelFontFamily)
                },
                textStyle = androidx.compose.ui.text.TextStyle(
                    color = PixelWhite,
                    fontFamily = PixelFontFamily,
                    fontSize = 14.sp
                ),
                singleLine = true,
                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PixelAccent,
                    unfocusedBorderColor = PixelBorder,
                    cursorColor = PixelGold
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(16.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                PixelButton(
                    text = "取消",
                    onClick = onDismiss,
                    color = PixelGray,
                    width = 100.dp
                )
                PixelButton(
                    text = "确定",
                    onClick = {
                        if (input.isNotBlank()) {
                            onConfirm(input)
                        }
                    },
                    width = 100.dp
                )
            }
        }
    }
}

@Composable
fun PixelConfirmDialog(
    title: String,
    message: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .background(PixelCard, RoundedCornerShape(4.dp))
                .border(2.dp, PixelAccent, RoundedCornerShape(4.dp))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                color = PixelGold,
                fontFamily = PixelFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            Spacer(Modifier.height(12.dp))

            Text(
                text = message,
                color = PixelWhite,
                fontFamily = PixelFontFamily,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(16.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                PixelButton(text = "取消", onClick = onDismiss, color = PixelGray, width = 100.dp)
                PixelButton(text = "确定", onClick = onConfirm, width = 100.dp)
            }
        }
    }
}
